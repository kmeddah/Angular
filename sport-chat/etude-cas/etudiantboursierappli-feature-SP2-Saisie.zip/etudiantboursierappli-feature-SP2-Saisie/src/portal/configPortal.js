// Fichier servant au lancement de l'application angular dans le portail Caf.fr
var appName = "cnafEtudiantBoursierApp";

var idAngular = namespace+"angularApp";
$("#"+idAngular).append('<app-root></app-root>');