import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-noneligibilite',
  templateUrl: './noneligibilite.component.html',
  styleUrls: ['./noneligibilite.component.css']
})
export class NoneligibiliteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
